import joblib
import numpy as np
import json

def model_fn(model_dir):
    return joblib.load(f"{model_dir}/model.joblib")

def input_fn(request_body, request_content_type):
    if request_content_type == "application/json":
        if isinstance(request_body, bytes):
            request_body = request_body.decode("utf-8")
        data = json.loads(request_body)
        return np.array(data)

    if request_content_type == "application/x-npy":
        return np.load(request_body)

    raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data, model):
    return model.predict(input_data)

def output_fn(prediction, response_content_type):
    return json.dumps(prediction.tolist())
